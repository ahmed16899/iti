import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css']
})
export class SecondComponent implements OnInit {

  constructor() { }
  index = 0
  timer:any
  arr=[`assets/img/1.jpg` ,`assets/img/2.jpg` , `assets/img/3.jpg`]
  imgPath=this.arr[this.index]
  ngOnInit(): void {
  }
  next(){
    //console.log(this.arr.length)
    if( this.index == this.arr.length-1)
    {
      //this.index = this.arr.length
      this.imgPath=this.arr[this.index]
    }
    else
    {
      this.index++
      this.imgPath=this.arr[this.index]
    }
  }
prev(){
  if( this.index == 0)
  {
    //this.index = this.arr.length
    this.imgPath=this.arr[this.index]
  }
  else
  {
    this.index--
    this.imgPath=this.arr[this.index]
  }
}
start()
{
    this.timer = setInterval(() =>{
      if( this.index == this.arr.length-1)
      {
        this.index = 0
        this.imgPath=this.arr[this.index]
      }
      else
      {
        this.index++
        this.imgPath=this.arr[this.index]
      }
    },1000)
}
End(){
  clearInterval( this.timer);
}

}
